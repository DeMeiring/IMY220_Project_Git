(()=>{
    alert("a thousand thank yous");
})()