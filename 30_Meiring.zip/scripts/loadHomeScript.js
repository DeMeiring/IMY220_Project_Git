(()=>{
    let origin = window.location.origin;
        $.ajax({
            url:'http://imy.up.ac.za/IMY220/u17074292/API.php',
            type:'GET',
            cache:false,
            data:{
                'gaImages':0,
            },
            success:(res)=>{
                objCount = Object.keys(res).length;
                for(let i=0;i<objCount;i++){
                    getUsername(res[i]['userID'],i);
                    loadComments(res[i]['galleryID']);
                }
                loadintoHTML(res);
            },
            error:(e)=>{
                console.log(e);
            }
        })
})()

function loadComments(galleryID){
    $.ajax( {
        url:origin+'http://imy.up.ac.za/IMY220/u17074292/API.php',
        type:'GET',
        cache:false,
        data:{
                'galleryIDComments':galleryID
            },
    success:(res)=>{
        let count = Object.keys(res).length;
        for(let i=0;i<count;i++){
            $('.commentContainer').eq(i).append('<p>'+res[i]['comment']+'</p>');
        }
    },
        error:(e)=>{
        console.log(e);
    }
})
}

function getUsername(uid , index){
    $.ajax({
        url:origin+'http://imy.up.ac.za/IMY220/u17074292/API.php',
        type:'GET',
        cache:false,
        data:{
            'userID':uid,
        },
        success:(res)=>{
            console.log(res);
             addTags(res[0]['username'],index);
        },
        error:(e)=>{
            console.log(e);
        }
    })
}

function addTags(username,index){
    userTag = '@'+username;
    $('.userName').eq(index).text(userTag);
}

function loadintoHTML(res){
    let count = 0;
    $('img').each(function(){
        $(this).attr('src',res[count]['filename']);
        count++;
    });
    count=0;
    $('.userCaption').each(function(){
        $(this).text(res[count]['caption'])
        count++;
    })
    count=0;
    $('.userHashtags').each(function(){
        $(this).text(res[count]['hashtags']);
        count++;
    })
    count=0;
}