There seems to be a problem with the loading of my images but it does work when localhost is used. 
That being said the ajax url is made for the server upload so it would not work if changed to localhost.
adjusting the url option of the effected ajax calls should repair the problem.